import numpy as np

from scipy.signal import find_peaks
from scipy.optimize import curve_fit

class cPamAnalyzer:
    nFrame = 120
    nX = 1280
    ROI = [800,1171]

    pix_to_fs = 6.4690 #using delay stage,  7.92 if using ppodl
    pam_modulation_threshold = 0.006
    
    err_Msg = []
    def __init__(self, 
                 ADC = None, 
                 ROI = None, 
                 smooth_winSize = 15, 
                 smooth_mode = 'Gaussian',
                 on_slice_str = '[0:8:2]',
                 off_slice_str = '[1:8:2]'):
        self.ADC = ADC
        if ROI is not None:
            self.ROI = ROI
        self.smooth_winSize = smooth_winSize
        self.smooth_mode = smooth_mode

        self.nPulses = 0
        self.whichPulse = 0
        self.IsShowPulseOnly = False

        self.On_slice_str = on_slice_str
        self.Off_slice_str = off_slice_str
        
        
    def updateROI(self,ROI):
        if ROI[0]< 0:
            self.ROI[0] = 0
        else:
            self.ROI[0] = ROI[0]
        if ROI[1] > self.nX-1:
            self.ROI[1] = self.nX-1
        else:
            self.ROI[1] = ROI[1]
            
    def updateADC(self, newADC):
        if newADC.shape != (self.nFrame, self.nX):
            self.err_Msg.append('new ADC wrong shape')
            return False
        else:
            self.ADC = newADC
            return True
    
    def updateSmoothWindow(self, size, mode):
        self.smooth_winSize = size
        self.smooth_mode = mode
        
    def _get_slice(self):
        try:
            on_s = eval(f'np.s_{self.On_slice_str}')
        except:
            self.err_Msg('wrong ON slice input, use default [0:8:2]')
            on_s = np.s_[0:8:2]

        try:
            off_s = eval(f'np.s_{self.Off_slice_str}')
        except:
            self.err_Msg('wrong OFF slice input, use default [1:8:2]')
            off_s = np.s_[1:8:2]

        self.on_s = on_s
        self.off_s = off_s
        
    def updateOnOffSlice(self,on_slice_str, off_slice_str):
        self.On_slice_str = on_slice_str
        self.Off_slice_str = off_slice_str
        self._get_slice()
        
    def _find_Pulses(self):
        # pix =  self.ROI[1]-10
        try:
            _background = 3000
            sample = np.average(self.ADC[:,self.ROI[0]:self.ROI[1]],axis = 1) - _background 
            if sample.max() < 50:
                self.err_Msg.append('find peak fails, pp laser too weak')
                return False # if pp laser too weak, then abort
            else:
                p,d = find_peaks(sample, distance = 1, height = 0.5*sample.max())           
        except:
            self.err_Msg.append('find peak fails, try to use another pixel')
            return False
        
        self._pulses = p
        self.All_Pairs = int(len(p)/2)
        # print(self.All_Pairs)
        if len(p) > 0:            
            return True
        else:
            self.err_Msg.append('No peak found')
            return False
    
    def _get_On_Off(self):
        self.ADC = np.asarray(self.ADC, dtype = float)
        if self._find_Pulses():
            self.PULSES = self.ADC[self._pulses,self.ROI[0]:self.ROI[1]]
            
            self.ON = self.PULSES[self.on_s,:]
            self.OFF = self.PULSES[self.off_s,:]
            n_On,npix = self.ON.shape
            self.n_On = n_On # number of frames with Xray (on frames)
            '''
            if the number of on/off pulses are not equal, then use the average
            of off pulses as reference off signal.
            '''
            if self.ON.shape != self.OFF.shape:
                _off = np.average(self.OFF, axis = 0)                
                self.OFF = np.vstack([_off]*self.n_On)
            return True
        else:
            
            return False

    def _smooth_curve(self, curve, winSize, mode = 'Square'):
        if mode == 'Square':
            _window = np.ones(winSize)/winSize
            return np.convolve(curve, _window, mode ='same')
            
        elif mode == 'Gaussian':
            z = np.arange(100)
            _window =  np.exp(-((z-50)/winSize)**2)/np.sqrt(np.pi)/winSize
            return np.convolve(curve, _window, mode ='same')
        
        else:
            return curve
            
    def processPAM(self):
        
        # def gau(x, a, b, c, d):
        #     # a : amplited
        #     # b : peak position
        #     # c : sigma
        #     # d : base
        #     return a * np.exp(-((x-b)/(1.414*c))**2) + d 
        
        if self._get_On_Off():
            if self.whichPulse > self.n_On:
               self.whichPulse = 0
           
            _on_all = self.ON
            _off_all = self.OFF
            
            _pam_all = (_on_all - _off_all)/(_on_all + _off_all)
            
            self.pam_all = _pam_all
            self.pam_sel = _pam_all[self.whichPulse]
            
            _smoothed_pam_all = np.apply_along_axis(
                        lambda m: self._smooth_curve(curve = m,
                                             winSize=self.smooth_winSize,
                                             mode = self.smooth_mode), 
                        axis = 1, 
                        arr = _pam_all
                        )
            self.smoothed_pam_all = _smoothed_pam_all
            self.smoothed_pam_sel = _smoothed_pam_all[self.whichPulse]
            
            self.pam_modulation_all = np.max(np.abs(np.min(_smoothed_pam_all,axis = 1)))                                                   
            
            g_all = np.gradient(_smoothed_pam_all, axis = 1) # gradient of smoothed curve            
            g_sel = g_all[self.whichPulse]
            
            self.pam_gradient_all = g_all
            self.pam_gradient_sel = g_sel
            
            pg_all = []
            for i in range(self.n_On):
                
                if self.pam_modulation_all[i] < self.pam_modulation_threshold:
                    pg_all.append(np.nan)
                else:
                    pg_all.append(np.argmax(g_all[i,:]))
            
            self.pam_peak_all = np.asarray(pg_all)
            self.pam_peak_sel = pg_all[self.whichPulse] # peak postion of gradient curve

            
            # if self.smooth_mode == 'Square':
            #     xdata = range(0,len(g))[pg-30:pg+30]
            #     ydata = g[pg-30:pg+30]
            #     try:
            #         popt, pcov = curve_fit(gau, xdata, ydata, p0 = [3,pg,10,-1])
            #     except:
            #         self.err_Msg.append('curve fitting wrong')
            #         return False
            #     self.pam_gradient_fit = [xdata,gau(xdata,*popt)]
            #     if IsWeakSignal== False:
            #         self.pam_peak = popt[1]                        
            #     else:
            #         self.pam_peak = np.nan
                
            # elif self.smooth_mode == 'Gaussian':
            #     if IsWeakSignal== False:
            #         self.pam_peak = pg                        
            #     else:
            #         self.pam_peak = np.nan
            #     self.pam_gradient_fit = np.nan
                
            # self.pam_gradient = g 
            # self.pam_peak_all = np.asarray(pg_all)
            # print(self.pam_peak_all)
            
            return True
        else:
            return False