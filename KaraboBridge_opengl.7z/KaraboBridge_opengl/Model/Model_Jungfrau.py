import numpy as np
class cJF16Analyzer:
    err_Msg = []
    '''
    JF1 and JF2 from karabo bridge are 3d array 
    if using online train-matcher, the data structure is: [nY, nX, nFrame]
    if using offline mode, the data structure is [nFrame, nY, nX]
    
    dataImg : frame averaged raw Jungfrau image data
    ON_img : on image, ROI only, frame resolved
    OFF_img: off image, ROI only, frame resolved
    
    SP_On : mean of On_img, spectral intensity
    SP_Off : mean of Off_img, spectral intensity
	'''
    nFrame = 16
    nY = 512
    nX = 1024
    bk = 5
    online_shape = (nY, nX, nFrame)
    offline_shape = (nFrame, nY, nX)
    regular_mode = (1,nY, nX)

    def __init__( self,
                 JF1 = None,
                 JF2 = None,
                 ROI = [0,512,0,1024],
                 mode = 'JF1',
                 On_slice = '',
                 Off_slice = ''):
        self.JF1 = JF1
        self.JF2 = JF2
        self.JF_rawdata = None
        self.ROI = ROI
        self.mode =  mode
        self.isOnline = False

    def updataPara(self, ROI, mode):
        self.ROI = ROI
        self.mode = mode


    def updateJF(self, JF, module = 1):
        if JF is None:

            self.err_Msg.append(f'Fail to load JF {module}')
            return False
        '''
        Junfrau adc data has different shape in online and offline modes
        check the shape of JF data
        '''
        isRegular = False
        if JF.shape == self.regular_mode:
                print('single frame mode')
                _jf = np.stack([JF[0]]*16)
                print(_jf.shape)
                JF = _jf
                isRegular = True
        else:
                if JF.shape == self.online_shape:
                    self.isOnline = True
                elif JF.shape == self.offline_shape:
                    self.isOnline = False
                else:
                    self.err_Msg.append(f'JF {module} data has wrong shape. {JF.shape} received')
                    return False
        
        '''        
        Here we changed the online data to the shape of offline mode [frame, nY, nX] by
        1. Rotate the JF array along axis 1 by 270 deg
        2. and then rotate it again along axis 2 by 90 deg
        '''
        if isRegular == False and self.isOnline == True:
            JF = np.rot90(np.rot90(JF,3,axes=(0,2)), axes=(0,1))
        
        if module == 1:            
            self.JF1 = JF

        elif module == 2:
            self.JF2 = JF
            
        return True    
    
    def processJF(self):
        '''
        Just get image of ROI for all 16 frames, no matter it has Xray signal or not
        we get
        1. JF_data : data in ROI for all 16 frames
        2. JF_img : frame avergaed data
        Returns
        -------
        None.

        '''
        if self.JF1 is None and self.JF2 is None:        
            print('No JF data to process!')
            self.JF_rawdata = None
            self.JF_Img = None
            return False
        
        if self.mode == 'JF 1':
            data = self.JF1

        elif self.mode == 'JF 2':
            data = self.JF2
        elif self.mode == 'both':
            data = np.concatenate((self.JF2, self.JF1), axis = 1)
        else:
            return False
        data[data<50] = 0
        self.JF_rawdata = data
        self.JF_data = data[:,self.ROI[0]:self.ROI[1], self.ROI[2]:self.ROI[3]]

        # get frame averaged img
        self.JF_Img_ROI = np.average(self.JF_data, axis = 0)
        self.JF_Img = np.average(data, axis = 0)
        print('JF raw data shape = ')
        print(self.JF_Img.shape)
        return True
        
    


