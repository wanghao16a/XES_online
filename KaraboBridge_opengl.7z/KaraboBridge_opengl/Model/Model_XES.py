import numpy as np
class cXESAnalyzer:
    err_Msg = []

    def __init__(self,
                 I0 = None,
                 JF_data = None, 
                 isIntraTrain = True,
                 on_slice_string = '',
                 off_slice_string = '',
                 XrayPulse_slice_string = '',
                 Digi_on_slice_string = '',
                 Dig_off_slice_string = ''):
        
        self.I0 = I0
        self.JF_data = JF_data
        self.isIntraTrain = isIntraTrain
        self.on_slice_string = on_slice_string
        self.off_slice_string = off_slice_string
        self.XrayPulse_slice_string = ''
        self.Digi_on_slice_string = Digi_on_slice_string
        self.Dig_off_slice_string = Dig_off_slice_string
        self.buffer = []
        self.SP_diff = np.nan
        self.nPulses = 0
    
    def updateData(self, I0, JF_data):
        '''        

        Parameters
        ----------
        I0 : 1d numpy array
            xray intensity.
        JF_data : 3d numpy array [nFrame, nY, nX]
            JF data in ROI.

        Returns
        -------
        None.

        '''
        if I0 is not None:
            self.I0 = I0
            # print(f'model XES received digitizer data {I0}')
        else:
            self.err_Msg.append('no digitizer signal in model XES updateData()')
            self.I0 = 1
        
        if JF_data is not None:
            self.JF_data = JF_data            
            self.JF_SP_allFrame = np.sum(self.JF_data, axis = (1,2))
        else:
            self.JF_data = None            
            self.err_Msg.append('no JF_data in model XES updateData()')
            return        
        
        if self.isIntraTrain == False:
            _data = {}
            _data['JF_data'] = self.JF_data
            _data['I0'] = self.I0
            self.buffer.append(_data)        
    
    def updatePara(self, isIntraTrain, 
                   on_slice_string, 
                   off_slice_string, 
                   XrayPulse_slice_string,
                   Digi_on_slice_string,
                   Dig_off_slice_string):
        
        self.isIntraTrain = isIntraTrain
        self.on_slice_string = on_slice_string
        self.off_slice_string = off_slice_string
        self.XrayPulse_slice_string = XrayPulse_slice_string
        self.Digi_on_slice_string = Digi_on_slice_string
        self.Dig_off_slice_string = Dig_off_slice_string
        
    def _get_slice(self):
        try:
            on_s = eval(f'np.s_{self.on_slice_string}')

        except:
            self.err_Msg.append('wrong ON slice input, use default [0:16:4]')
            on_s = np.s_[0:16:4]

        try:
            off_s = eval(f'np.s_{self.off_slice_string}')
        except:
            self.err_Msg('wrong OFF slice input, use default [2:16:4]')
            off_s = np.s_[2:16:4]
        
        try:
            all_s = eval(f'np.s_{self.XrayPulse_slice_string}')
        except:
            self.err_Msg('wrong X-ray pulse slice string input, use all')
            all_s = np.s_[0:16:2]
        
        try:
            digi_on_s = eval(f'np.s_{self.Digi_on_slice_string}')

        except:
            self.err_Msg.append('wrong ON slice input, use default [0:8:2]')
            digi_on_s = np.s_[0:8:2]

        try:
            digi_off_s = eval(f'np.s_{self.Dig_off_slice_string}')
        except:
            self.err_Msg('wrong OFF slice input, use default [1:8:2]')
            digi_off_s = np.s_[1:8:2]

        self.on_s = on_s
        self.off_s = off_s
        self.all_s = all_s
        self.digi_on_s = digi_on_s
        self.digi_off_s = digi_off_s
    
    def _ProcessXES_intra(self):
        '''
        This processor is for intra train mode.

        ON_data :  JF ROI 3d array [frame, Y, X], for frames with PP laser
        OFF_data : JF ROI 3d array [frame, Y, X], for frames without PP laser
        
        SP_on  : 2d array [pulse, x],  XES spectrum and normalized XES spectrum (integrate over y )  with PP laser
        SP_off : 2d array [pulse ,x],  XES spectrum without PP laser
        SP : 

        SP_on_norm : normailzed SP_on, divided by I0_on (digitizer signal for Xray diode, 1d array [pulse])
        SP_off_norm: normalized SP_off
        
        SP_diff : 2d array [pulse, x], difference between SP_on_norm and SP_off_norm

        '''
        if self.JF_data is None:
            self.err_Msg.append('Model_XES cannot process intra data, no JF data')
            return False
        
        if self.I0 is None:
            self.err_Msg.append('Model_XES cannot process intra data, no Digitizer data')
            return False       

        self._get_slice()

        ON_data = self.JF_data[self.on_s] 
        OFF_data = self.JF_data[self.off_s] 
        
        self.I0_on = self.I0[self.digi_on_s] # digitizer for Xray diode, 1d array, for frames with PP laser
        self.I0_off = self.I0[self.digi_off_s] # digitizer for Xray diode, 1d array, for frames without PP laser

        if self.I0_on.shape != self.I0_off.shape:
            return False
        self.I0_intra = np.dstack((self.I0_on,self.I0_off)).ravel()
                
        self.SP_on = np.nanmean(ON_data, axis = 1)  
        self.SP_off = np.nanmean(OFF_data, axis = 1)
        
        if len(self.SP_on) != len(self.I0_on):
            return False
        
        if len(self.SP_off) != len(self.I0_off):
            return False
        
        # JF total counts for on/off frames
        self.JF_SP_on = np.nanmean(ON_data, axis = (1,2))
        self.JF_SP_off = np.nanmean(OFF_data, axis = (1,2))
        self.JF_SP_intra = np.dstack((self.JF_SP_on,self.JF_SP_off)).ravel()
        
        self.SP_on_norm = (self.SP_on.T / self.I0_on).T
        self.SP_off_norm = (self.SP_off.T / self.I0_off).T
        
        self.SP_diff =self.SP_on -self.SP_off  #self.SP_on_norm - self.SP_off_norm

        self.nPulses = len(self.SP_diff)
        return True
    
    def _ProcessXES_inter(self):
        '''
        train on/off modulation
        '''
        print(f'{len(self.buffer)} data in buffer')
        if len(self.buffer) < 2:
            
            self.diff_img = np.nan
            self.SP_diff = np.nan
            return False
        else:
            self._get_slice()
            
            _pre_data =  self.buffer.pop(0)# data from previous train
            _cur_data = self.buffer.pop(0)
            
            if _pre_data['JF_data'].shape != _cur_data['JF_data'].shape:
                self.buffer.clear()
                return False
            
            pre_JF_data = _pre_data['JF_data']#[self.all_s]
            print('inter mode, previous data shape')
            print(pre_JF_data.shape)
            pre_I0 = 1#np.nanmean(_pre_data['I0'])            
            
            
            cur_JF_data = _cur_data['JF_data']#[self.all_s]
            print('inter mode, current data shape')
            print(cur_JF_data.shape)
            
            cur_I0 = 1#np.nanmean(_cur_data['I0'])

            self.JF_SP_inter = np.nanmean(self.JF_SP_allFrame[self.all_s])
            SP_cur = np.nanmean(cur_JF_data, axis = (0,1))
            SP_pre = np.nanmean(pre_JF_data, axis = (0,1))
            
            '''
            check the following code!!!!!!, 
            not sure if it is a ringt way to do normalization in inter train mode!!!!
            '''
            SP_cur_norm = SP_cur / (cur_I0)
            SP_pre_norm = SP_pre / (pre_I0) 
            
            self.SP_diff = SP_cur_norm - SP_pre_norm
            print(f'intra sp {self.SP_diff}')
            self.nPulses = 1
            self.I0_inter = cur_I0
            
            self.buffer.clear()
            return True
    
    def processXES(self):
        Intra_output = {}
        Inter_output = {}
        
        if self.isIntraTrain == True:
            if self._ProcessXES_intra() == True:
                Intra_output['SP_diff'] = self.SP_diff
                Intra_output['nPulses'] = self.nPulses
                Intra_output['I0'] = self.I0_intra
                Intra_output['JF_SP'] = self.JF_SP_intra

            else:
                Intra_output['SP_diff'] = np.nan
                Intra_output['I0'] = np.nan
                Intra_output['nPulses'] =0
                Intra_output['JF_SP'] = np.nan
                
            
            self.output = Intra_output
            return
              
        else:
            if self._ProcessXES_inter() == True:
                Inter_output['SP_diff'] = self.SP_diff
                Inter_output['nPulses'] = self.nPulses
                Inter_output['I0'] = self.I0_inter
                Inter_output['JF_SP'] = self.JF_SP_inter
            else:
                Inter_output['SP_diff'] = np.nan
                Inter_output['I0'] = np.nan
                Inter_output['nPulses'] =0
                Inter_output['JF_SP'] = np.nan
                
            self.output = Inter_output
            return
            
            
            
