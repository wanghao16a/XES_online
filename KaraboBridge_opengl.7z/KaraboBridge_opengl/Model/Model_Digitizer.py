import numpy as np

from scipy.signal import find_peaks
from scipy.optimize import curve_fit

class cDigitizerAnalyzer:
    '''
    digi_raw : input raw digitizer data
    digi_apd : input apd integral data

    Digi_nobk: background substracted digi raw
    peaks: Xray peaks
    I0: Xray power
    nPulses : how many xray pulses in the train
    '''
    
    bk = 1761 # background of digitizer
    err_Msg = []
    def __init__(self, digi_raw = None, 
                 digi_apd = None, 
                 Use_peakFinding = False, 
                 Use_apd = True,
                 peakFindingPara = [7000,200]
                 ):

        self.Use_peakFinding = Use_peakFinding
        self.Use_apd = Use_apd
        self.digi_raw = digi_raw
        self.digi_apd = digi_apd
        self.peakFindingPara = peakFindingPara
        self.peaks = []
        self.nPulses = 0
        
    def update_digi_data(self, digi_raw, digi_apd):
        self.digi_raw = digi_raw
        self.digi_apd = digi_apd
    
    def _update_udf_Peaks(self, udf_Para):
        p0, sep, nPeaks = udf_Para
        pn = p0 + sep * nPeaks
        p = np.arange(p0, pn, sep)
        self.udf_peaks = p
        
    def _update_peakFinding_Para(self, para):
        if len(para) == 2:
            self.peakFindingPara = para
        
    def updatePara(self, Use_apd, Use_peakFinding, peakFinding_Para, udf_Para):
        self.Use_apd = Use_apd
        self.Use_peakFinding = Use_peakFinding
        self._update_peakFinding_Para(peakFinding_Para)
        self._update_udf_Peaks(udf_Para)
    
    def _process_digi_apd(self):
        if self.digi_apd is None:
            self.err_Msg.append('no apd signal.')            
            self.I0 = None
            return False
        else:
            self.I0 = self.digi_apd
            self.nPulses = len(self.I0)
            return True
        
    def _update_bk(self, l = 100):
        self.bk = np.average(self.digi_raw[:-l])
        
    def _process_digi_raw(self):
        if self.digi_raw is None:
            self.err_Msg.append('no raw signal.')
            self.I0 = None
            return False
        
        else:
            self._update_bk(l = 100)
            _digi_nobk = np.abs(self.digi_raw - self.bk)

            self.Digi_nobk = _digi_nobk
            
            if self.Use_peakFinding == False and len(self.udf_peaks) > 0:
                _peaks = self.udf_peaks                
                
            else: # if find peaks 
                p,d = find_peaks(self.Digi_nobk,
                                 height = self.peakFindingPara[0],
                                 distance = self.peakFindingPara[1])
                _peaks = p # position of xray pulses signal
            
            I0 = []
            for i in _peaks:
                '''
                our digitizer is nosisy, so here we try to use the region around peak as
                signal, and a region further after the peak as background.
                '''
                if i+15 < len(_digi_nobk) and i-500 > 0:
                    _signal = np.mean(_digi_nobk[i-15:i+15])
                    _bk = np.mean(_digi_nobk[i-500:i-250])
                    # print(f'digitier model : calculated I) = {_signal - _bk}')
                    I0.append( _signal - _bk)
                
            self.I0 = np.asarray(I0,dtype = float)
            self.peaks = _peaks
            self.nPulses = len(self.I0)
            return True
          
    def processDigi(self):
        if self.Use_apd == True:
            return self._process_digi_apd()
        else:
            
            return self._process_digi_raw()
            
                
                
                
                    

            
            
    
    
            
    
    